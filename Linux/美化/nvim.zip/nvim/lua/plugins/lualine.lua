require('lualine').setup({
  options = {
    theme = 'tokyonight'
  }
})
