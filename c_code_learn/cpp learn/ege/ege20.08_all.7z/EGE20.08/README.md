# EGE 20.08 安装包

- 安装教程 <https://xege.org/beginner-lesson-1.html>
- IDE下载 <https://xege.org/install_and_config>
- 源代码 <https://github.com/wysaid/xege>
